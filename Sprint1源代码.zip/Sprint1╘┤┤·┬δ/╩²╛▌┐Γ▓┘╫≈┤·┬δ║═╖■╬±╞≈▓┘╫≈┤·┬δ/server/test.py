
source ="hello,nihao,woshinidie,123,456,789"
print(source.split(',')[2])