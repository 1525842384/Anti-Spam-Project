# -*- encoding: utf-8 -*-
import socket
import sys
IP = '192.168.1.105' #填写服务器端的IP地址
port = 40005 #端口号必须一致
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:
    s.connect((IP,port))
except Exception as e:
    print('server not find or not open')
    sys.exit()
while True:
    operation = input('注册请输1，登录请输2, 修改密码请输3, 查询收件夹请输4: ')
    #注册功能
    if(operation.strip() == '1'):
       #注册信息
       trigger = "register,xiaohong,87654321"
       s.sendall(trigger.encode())
       data = s.recv(1024)
       data = data.decode()
       print('recieved:', data)
    #登录功能
    elif(operation.strip() == '2'):
       #登录信息
       trigger = "login,xiaohong,87654321"
       s.sendall(trigger.encode())
       data = s.recv(1024)
       data = data.decode()
       print('recieved:', data)
    #修改密码功能
    elif(operation.strip() == '3'):
        #修改密码信息
        trigger = "updatepassword,xiaohong,87654321,7777777"
        s.sendall(trigger.encode())
        data = s.recv(1024)
        data = data.decode()
        print('recieved:', data)
    #查询收件箱
    elif (operation.strip() == '4'):
        # 修改密码信息
        trigger = "allReceiveEmail,qining926"
        s.sendall(trigger.encode())
        for i in range(2):
            data = s.recv(1024)
            data = data.decode()
            print('recieved:', data)
    if trigger.lower() == '1':#发送1结束连接
        break
s.close()
