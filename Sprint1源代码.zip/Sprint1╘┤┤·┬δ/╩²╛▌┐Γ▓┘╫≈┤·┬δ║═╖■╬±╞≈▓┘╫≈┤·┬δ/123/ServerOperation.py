
names = '''a123,a234,a345,a456,a567'''
list = names.split(',')
print(list[2])