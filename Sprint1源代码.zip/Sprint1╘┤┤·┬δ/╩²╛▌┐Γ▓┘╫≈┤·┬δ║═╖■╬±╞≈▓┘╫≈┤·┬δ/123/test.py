# encoding=utf-8
import pymysql

account1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver', 'Shixun1234','email',charset='utf8')
cursor = account1.cursor()

emailaccount = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver', 'Shixun1234','emailaccount',charset='utf8')
cursor2 = emailaccount.cursor()

emailsender = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver', 'Shixun1234','emailsender',charset='utf8')
cursor3 = emailsender.cursor()

contact1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver', 'Shixun1234','contact',charset='utf8')
cursor4 = contact1.cursor()

def newTable():
    cursor.execute("DROP TABLE IF EXISTS ACCOUNT")
    sql = """CREATE TABLE ACCOUNT (
            EmailName CHAR(20) NOT NULL,
            Password CHAR(16) NOT NULL,
            ContactNum INT(5),
            ReceiveEmailNum INT(5),
            SendEmailNum INT(5))CHARSET=utf8
            """
    cursor.execute(sql)

def insertAccount(name, password):
    uname = searchAccountName(name)
    sql = "INSERT INTO ACCOUNT VALUES('%s', '%s',0,0,0)"%(name, password)
    try:
        # 执行sql语句
        cursor.execute(sql)
        # 执行sql语句
        account1.commit()
    except:
        # 发生错误时回滚
        account1.rollback()
def insertEmailAccount(name):
    try:
        cursor2.execute("CREATE TABLE %s (tit CHAR(25), date CHAR(20), text TEXT, sender CHAR(20))CHARSET=utf8"%name)
        emailaccount.commit()
    except:
        emailaccount.rollback()
def insertEmailSender(name):
    try:
        cursor3.execute("CREATE TABLE %s (tit CHAR(25), date CHAR(20), text TEXT, receiver CHAR(20))CHARSET=utf8"%name)
        emailsender.commit()
    except:
        emailsender.rollback()
def insertContactTable(name):
    try:
        cursor4.execute("CREATE TABLE %s (emailname CHAR(20), nickname CHAR(20), type CHAR(10))CHARSET=utf8"%name)
        contact1.commit()
    except:
        contact1.rollback()
#数据库注册，新建一个账号，并给此账户名建一个收件箱表
def register(name,password):
    if searchAccountName(name):
        print("用户已存在")
        return "defeat"
    else:
       insertAccount(name,password)
       insertEmailAccount(name)
       insertEmailSender(name)
       insertContactTable(name)
       result = "succeed"
       return result

def login(name,password):
    uName = searchAccountName(name)
    result = 'defeat'
    if uName:
        uPass = str(searchAccountPassword(name))
        if (uPass.strip() == password.strip()):
            result = "succeed"
            return result
        else:
            result = "defeat"
            return result
    else:
        print("账户不存在")
        return result

#数据库查询账户的密码0
def searchAccountPassword(name):
    sql = "SELECT * FROM ACCOUNT WHERE EmailName = '%s'"%(name)
    try:
        # 执行SQL语句
        cursor.execute(sql)
        # 获取所有记录列表
        results = cursor.fetchall()
        for row in results:
           uname = row[0]
           upassword = row[1]
           # 打印结果
           print("name=%s,password=%s" % \
                (uname, upassword))
           return upassword
    except:
        print("Error: unable to fetch data")

#数据库查询账户是否存在
def searchAccountName(Emailname):
    sql = "SELECT * FROM ACCOUNT WHERE EmailName = '%s'"%(Emailname)
    try:
        # 执行SQL语句
        cursor.execute(sql)
        # 获取所有记录列表
        results = cursor.fetchall()
        for row in results:
           uname = row[0]
           upassword = row[1]
           #ucontactnum = row[2]
           #ureceivenum = row[3]
           #usendnum = row[4]
           # 打印结果
           print("EmailName=%s,Password=%s" % \
                (uname, upassword))
           return uname
    except:
        print("Error: unable to fetch data")

#查询账户信息
def searchAccount(Emailname):
    sql = "SELECT * FROM ACCOUNT WHERE EmailName = '%s'"%(Emailname)
    try:
        # 执行SQL语句
        cursor.execute(sql)
        # 获取所有记录列表
        results = cursor.fetchall()
        for row in results:
           uname = row[0]
           upassword = row[1]
           ucontactnum = row[2]
           ureceivenum = row[3]
           usendnum = row[4]
           # 打印结果
           print("EmailName=%s,Password=%s" % \
                (uname, upassword))
           return uname,upassword,ucontactnum,ureceivenum,usendnum
    except:
        print("Error: unable to fetch data")

def deleteAccount(name,password):
    sql = "DELETE FROM ACCOUNT WHERE EmailName = '%s' AND Password = '%s'" % (name, password)
    try:
        # 执行SQL语句
        cursor.execute(sql)
        # 提交修改
        account1.commit()
    except:
        # 发生错误时回滚
        account1.rollback()
def deleteEmailAccountTable(name):
    try:
        cursor2.execute("DROP TABLE IF EXISTS %s" % name)
        emailaccount.commit()
    except:
        emailaccount.rollback()
def deleteEmailSenderTable(name):
    try:
        cursor3.execute("DROP TABLE IF EXISTS %s" % name)
        emailsender.commit()
    except:
        emailsender.rollback()
def deleteContactTable(name):
    try:
        cursor4.execute("DROP TABLE IF EXISTS %s" % name)
        contact1.commit()
    except:
        contact1.rollback()
#数据库删除一个账户及收件箱及已发送箱
def delete(name,password):
    upassword = str(searchAccountPassword(name))
    upass = str(password)
    print(upassword)
    print(upass)
    if upassword.strip() != upass.strip():
       print("密码错误")
    else:
       deleteAccount(name,password)
       deleteEmailAccountTable(name)
       deleteEmailSenderTable(name)
       deleteContactTable(name)

#数据库修改账户密码
def updateAccountPassword(name, oldpass, newpass):
    uName = searchAccountName(name)
    result = 'defeat'
    if uName:
       upassword = str(searchAccountPassword(name))
       uoldpass = str(oldpass)
       print(upassword)
       print(oldpass)
       if upassword.strip() != uoldpass.strip():
           print("密码错误")
           return result
       else:
          sql = "UPDATE ACCOUNT SET Password = '%s' WHERE EmailName = '%s' AND Password = '%s'" % \
                (newpass,name,oldpass)
          try:
              # 执行SQL语句
              cursor.execute(sql)
              # 提交到数据库执行
              account1.commit()
          except:
              # 发生错误时回滚
              account1.rollback()
          result = 'succeed'
          return result
    else:
        print("用户不存在")
        return result

def updateEmailNum(sender,receiver,num):
    sName,sPass,sContact,sReceive,sSend = searchAccount(sender)
    rName,rPass,rContact,rReceive,rSend = searchAccount(receiver)
    if sName and rName:
        sql = "UPDATE ACCOUNT SET ReceiveEmailNum = %s WHERE EmailName = '%s'" % \
              (rReceive+num,rName)
        sql2 = "UPDATE ACCOUNT SET SendEmailNum = %s WHERE EmailName = '%s'" % \
              (sSend+num,sName)
        try:
            # 执行SQL语句
            cursor.execute(sql)
            cursor.execute(sql2)
            # 提交到数据库执行
            account1.commit()
        except:
            # 发生错误时回滚
            account1.rollback()
    else:
        print("数目错误")

#往下是邮箱的功能
#收件箱数据库收到一封新邮件
def newEmail(receiver,title,date,text,sender):
    if searchAccountName(receiver) and searchAccountName(sender):
        searchAccountName(receiver)
        sql = "INSERT INTO %s VALUES('%s', '%s', '%s', '%s')" % (receiver, title, date, text, sender)
        try:
            cursor2.execute(sql)
            emailaccount.commit()
        except:
            emailaccount.rollback()
        sql2 = "INSERT INTO %s VALUES('%s', '%s', '%s', '%s')" % (sender, title, date, text, receiver)
        try:
            cursor3.execute(sql2)
            emailsender.commit()
        except:
            emailsender.rollback()
        updateEmailNum(sender,receiver,1)
    else:
        print("投递用户不存在")

#数据库查询邮件信息
def searchEmailByTit(receiver,title):
    sql = "SELECT * FROM %s WHERE tit = '%s'" % (receiver,title)
    try:
        # 执行SQL语句
        cursor2.execute(sql)
        # 获取所有记录列表
        results = cursor2.fetchall()
        print(results)
        for row in results:
            etitle = row[0]
            edate = row[1]
            etext = row[2]
            esender = row[3]
            ereceiver = receiver
            # 打印结果
            print("title=%s,date=%s,text=%s,sender=%s,receiver=%s" % \
                  (etitle,edate,etext,esender,ereceiver))
            return etitle,edate,etext,esender
    except:
        print("Error: unable to fetch data")

def deleteSendEmail(sender,title):
    sql = "DELETE FROM %s WHERE tit = '%s'"%(sender,title)
    try:
        cursor3.execute(sql)
        emailsender.commit()
    except:
        emailsender.rollback()
def deleteReceiveEmail(receiver,title):
    sql = "DELETE FROM %s WHERE tit = '%s'"%(receiver,title)
    try:
        cursor2.execute(sql)
        emailaccount.commit()
    except:
        emailaccount.rollback()

#数据库删除一封邮件
def deleteEmail(receiver,title):
    etitle, edate, etext, esender = searchEmailByTit(receiver,title)
    if etitle:
       sql = "DELETE FROM %s WHERE tit = '%s'"%(receiver,title)
       try:
           cursor2.execute(sql)
           emailaccount.commit()
       except:
           emailaccount.rollback()
       sql2 = "DELETE FROM %s WHERE tit = '%s'"%(esender,title)
       try:
           cursor3.execute(sql2)
           emailsender.commit()
       except:
           emailsender.rollback()
       updateEmailNum(esender, receiver, -1)
    else:
        print("邮件不存在")

#遍历收件箱
def allReceiveEmail(receiver):
    rName, rPass, rContact, rReceive, rSend = searchAccount(receiver)
    sql = "SELECT * FROM %s " % (rName)
    REmailTitList = []
    REmailDateList = []
    REmailTextList = []
    REmailSenderList = []
    try:
        # 执行SQL语句
        cursor2.execute(sql)
        # 获取所有记录列表
        for i in range(rReceive):
            results = cursor2.fetchone()
            print(results)
            REmailTitList.append(results[0])
            REmailDateList.append(results[1])
            REmailTextList.append(results[2])
            REmailSenderList.append(results[3])
            print("title=%s,date=%s,text=%s,sender=%s" % \
                (REmailTitList[i], REmailDateList[i], REmailTextList[i], REmailSenderList[i]))
        return REmailTitList,REmailDateList,REmailTextList,REmailSenderList,rReceive
    except:
        print("Error: unable to fetch data")

#遍历已发送邮件
def allSendEmail(sender):
    sName, sPass, sContact, sReceive, sSend = searchAccount(sender)
    sql = "SELECT * FROM %s " % (sName)
    SEmailTitList = []
    SEmailDateList = []
    SEmailTextList = []
    SEmailSenderList = []
    try:
        # 执行SQL语句
        cursor3.execute(sql)
        # 获取所有记录列表
        for i in range(sSend):
            results = cursor3.fetchone()
            SEmailTitList.append(results[0])
            SEmailDateList.append(results[1])
            SEmailTextList.append(results[2])
            SEmailSenderList.append(results[3])
            print("title=%s,date=%s,text=%s,sender=%s" % \
                  (SEmailTitList[i], SEmailDateList[i], SEmailTextList[i], SEmailSenderList[i]))
        return SEmailTitList, SEmailDateList, SEmailTextList, SEmailSenderList, sSend
    except:
        print("Error: unable to fetch data")

#往下是联系人操作
#添加联系人
def addContact(user,emailname,nickname,tyoe):
    if searchAccountName(emailname):
       sql = "INSERT INTO %s VALUES('%s', '%s', '%s')" % (user, emailname, nickname, tyoe)
       try:
           cursor4.execute(sql)
           contact1.commit()
       except:
           contact1.rollback()
       updateContactNum(user,1)
    else:
        print("目标邮箱地址无效")

#更新联系人昵称
def updateNickname(user,emailname,nickname):
    sql = "UPDATE %s SET nickname = '%s' WHERE emailname = '%s'" % (user,nickname,emailname)
    try:
        cursor4.execute(sql)
        contact1.commit()
    except:
        contact1.rollback()

#更新联系人的数量
def updateContactNum(user,num):
    uName,uPass,uContact,uReceive,uSend = searchAccount(user)
    if uName:
        sql = "UPDATE ACCOUNT SET ContactNum = %s WHERE EmailName = '%s'" % \
              (uContact+num,uName)
        try:
            # 执行SQL语句
            cursor.execute(sql)
            # 提交到数据库执行
            account1.commit()
        except:
            # 发生错误时回滚
            account1.rollback()
    else:
        print("账户不存在")

#删除联系人
def deleteContact(user,emailname):
    if searchAccountName(emailname):
       sql = "delete from %s WHERE emailname = '%s'" % (user,emailname)
       try:
           cursor4.execute(sql)
           contact1.commit()
       except:
           contact1.rollback()
       updateContactNum(user,-1)
    else:
        print("联系人不存在")

def allContact(emailname):
    uName, uPass, uContact, uReceive, uSend = searchAccount(emailname)
    sql = "SELECT * FROM %s " % (uName)
    EmailNameList = []
    EmailNickNameList = []
    TypeList = []
    try:
        # 执行SQL语句
        cursor4.execute(sql)
        # 获取所有记录列表
        for i in range(uContact):
            results = cursor4.fetchone()
            EmailNameList.append(results[0])
            EmailNickNameList.append(results[1])
            TypeList.append(results[2])
            print("emailname=%s,nickname=%s,type=%s" % \
                  (EmailNameList[i], EmailNickNameList[i], TypeList[i]))
        return EmailNameList, EmailNickNameList, TypeList, uContact
    except:
        print("Error: unable to fetch data")


if __name__ == "__main__":
    #newTable()
    #addContact('qining926','huangshaohao','儿子','白名单')
    #updateNickname('huangshaohao','qining926','father')
    #deleteContact('qining926','huangying')
    #updateContactNum('huangying',1)
    #deleteEmail('qining926','测试邮件')
    #register('huangshaohao',99999999)
    #register('huangying',12345678)
    #delete('xiaohong',87654321)
    #delete('huangying',12345678)
    #delete('huangshaohao',66666666)
    #newEmail('qining926','邮箱邮件2','2019-8-25 11:00','12345678','huangshaohao')
    #newEmail('qining926', '邮箱邮件5', '2019-8-25 15:03', '测试成功123', 'huangying')
    #newEmail('xiaoming', '邮箱邮件3', '2019-8-23 9:39', '测试成功', 'qining926')
    #searchEmailByTit('qining926','邮箱邮件1')
    #deleteEmail('xiaoming','邮箱邮件3')
    #deleteSendEmail('huangying','互发测试邮件')
    #deleteReceiveEmail('qining926','互发测试邮件')
    #allSendEmail('huangying')
    allContact('qining926')