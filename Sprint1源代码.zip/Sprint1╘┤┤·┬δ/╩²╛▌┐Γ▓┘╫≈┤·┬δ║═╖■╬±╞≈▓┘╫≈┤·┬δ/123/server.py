# -*- encoding: utf-8 -*-
import socket
import test

IP = ""  # 服务器端可以写"localhost"，可以为空字符串""，可以为本机IP地址
port = 40005  # 端口号
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((IP, port))
s.listen(5)
print('listen at port :', port)
conn, addr = s.accept()
print('connected by', addr)

while True:
    data = conn.recv(1024)
    data = data.decode()  # 解码
    if not data:
        break
    print('recieved message:', data)
    list = data.split(',')
    operation = str(list[0])
    # 注册操作
    if (operation.strip() == "register"):
        result = test.register(list[1], list[2])
        if (result.strip() == "succeed"):
            print("注册成功")
            send = result.strip()
        else:
            print("注册失败")
            send = "defeat"
        conn.sendall(send.encode())  # 再编码发送
    elif (operation.strip() == "login"):
        result = test.login(list[1],list[2])
        if (result.strip() == "succeed"):
            print("登录成功")
            send = result.strip()
        else:
            print("登录失败")
            send = "defeat"
        conn.sendall(send.encode())  # 再编码发送
    elif (operation.strip() == "updatepassword"):
        result = test.updateAccountPassword(list[1],list[2],list[3])
        if(result.strip() == "succeed"):
           print("修改成功")
           send = result.strip()
        else:
           print("修改失败")
           send = "defeat"
        conn.sendall(send.encode())  # 再编码发送
    elif (operation.strip() == "allReceiveEmail"):
        REmailTitList,REmailDateList,REmailTextList,REmailSenderList,num = test.allReceiveEmail(list[1])
        for i in range(num):
           result = REmailTitList[i] + "," + REmailDateList[i] + "," + REmailTextList[i] + "," + REmailSenderList[i]
           send = result.strip()
           conn.sendall(send.encode())  # 再编码发送

conn.close()
s.close()
